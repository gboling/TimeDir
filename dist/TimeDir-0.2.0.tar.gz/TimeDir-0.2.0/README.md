# timedir

A Python app which will produce a directory tree in this format:
`output_dir/year/month/day/hour/min`

Input can be either the last modified time for a file or current date and time.


by J. Grant Boling [gboling]at[gmail]dot[com]